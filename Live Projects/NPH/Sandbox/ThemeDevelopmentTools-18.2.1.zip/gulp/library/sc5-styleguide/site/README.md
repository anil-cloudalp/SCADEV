# SC5 Styleguide landing page

The `gh-pages` branch stores the landing page representing the tool.

## How to develop

1. Run `npm install`
1. Run `gulp watch` to automatically compile changes when styles are changed
1. Commit all the files including the generated ones
1. Make a PR into upstream `gh-pages` branch
