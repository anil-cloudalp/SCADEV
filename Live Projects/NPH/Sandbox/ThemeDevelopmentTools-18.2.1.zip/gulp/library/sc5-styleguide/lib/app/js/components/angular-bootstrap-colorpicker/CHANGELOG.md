v3.0.23 - 18 Dec 2015 2015 (JuanHB)
---------------------------------------

- [c9c745e8bb43f31d680f88590983c5089d057c0e] Solution for Exception when using non-input elements

v3.0.14 - Mon, 21 Apr 2015 (jakubsikora)
---------------------------------------

- [37faabf62b55962f28959981085662cb407f2a48] scrolling fix

v3.0.13 - Fri, 27 Mar 2015 (ste2425)
---------------------------------------

- [738bff892714513551d1379254d8d71aa7197ae5] extended existing events for on select etc

v3.0.12 - Mon, 16 Feb 2015 (mattlewis92)
---------------------------------------

- [986eb8c651f5d38b429b5c698cc8c92043fa0579] Add a colorpicker-is-open attribute for controlling the visibility of the popover

v3.0.11 - Thu, 22 Dec 2014
---------------------------------------

- [28956c7ce9] min versions / gulp

v3.0.10 - Thu, 18 Dec 2014
---------------------------------------

- [4c62f5d, e1f5021, de84abb, 993d509]) Bugfix initial input val
