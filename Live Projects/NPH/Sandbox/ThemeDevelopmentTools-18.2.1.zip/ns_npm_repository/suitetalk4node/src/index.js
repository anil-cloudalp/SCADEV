var tool = require('./tool'); 
require('./util'); 
require('./templates');
require('./fields')
require('./communications');
require('./operations'); 

// require('./easy/index'); 

tool.templatesInit(); 


module.exports = tool; 

